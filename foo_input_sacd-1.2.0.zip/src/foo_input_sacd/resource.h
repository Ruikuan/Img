﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by foo_input_sacd.rc
//
#define IDD_SACD_PREFERENCES            101
#define IDC_OUTPUT_MODE_TEXT            1001
#define IDC_OUTPUT_MODE_COMBO           1002
#define IDC_VOLUME_TEXT                 1003
#define IDC_VOLUME_ADJ_COMBO            1004
#define IDC_LOG_OVERLOADS               1005
#define IDC_SAMPLERATE_TEXT             1006
#define IDC_SAMPLERATE_COMBO            1007
#define IDC_CONVERTER_MODE_TEXT         1008
#define IDC_CONVERTER_MODE_COMBO        1009
#define IDC_LOAD_FIR_BUTTON             1010
#define IDC_SAVE_FIR_BUTTON             1011
#define IDC_INSTALLABLE_FILTER_TEXT     1012
#define IDC_AREA_TEXT                   1013
#define IDC_AREA_COMBO                  1014
#define IDC_EDITABLE_TAGS               1015
#define IDC_STORE_TAGS_WITH_ISO         1016
#define IDC_EMASTER                     1017
#define IDC_LINKED_TAGS                 1018
#define IDC_DSD_PROCESSOR_TEXT          1019
#define IDC_DSD_PROCESSOR_COMBO         1020
#define IDC_TRACE                       1021
#define IDC_LFE_ADJ_COMBO               1022
#define IDC_DOP_FOR_CONVERTER           1023
#define IDC_STDTAGS                     1024
#define IDC_STD_TAGS                    1024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
