/*
* DSD Converter DSP plugin
* Copyright (c) 2016-2018 Maxim V.Anisiutkin <maxim.anisiutkin@gmail.com>
*/

#include "dsd_processor_service.h"

constexpr GUID dsd_processor_service::class_guid = { 0x115368d7, 0xa110, 0x48c0, { 0xae, 0x19, 0xbb, 0xc6, 0xd1, 0x95, 0x8a, 0x61 } };
